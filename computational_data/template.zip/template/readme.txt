1、向对应的文件夹上传对应的结构数据文件；
2、向Excel表中填写需要上传的数据；
3、上传时，每条DOI下的不同的Formula至少要对应一个基底文件（结构文件）

1.Upload the corresponding structural data file to the respective folder;
2.Fill in the required data in the Excel sheet;
3.Before the upload, make sure each unique Formula under a specific DOI must be associated with at least one base file (structural file).
上传压缩文件即可。